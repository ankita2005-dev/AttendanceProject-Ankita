package attendance.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LeaveToTeacher extends JFrame {

    public LeaveToTeacher() {
        setTitle("Leave Request to Teacher");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));

        JLabel title = new JLabel("Leave Requests", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        // Table Data
        String[] columnNames = {"Name", "Class", "Roll No", "Date", "Reason"};
        Object[][] data = {
            {"Ishita Sharma", "BCA-1", "101", "2025-04-12", "Family Function"},
            {"Rohan Malhotra", "BCA-1", "102", "2025-04-13", "Medical"},
            {"Sakshi Verma", "BCA-1", "103", "2025-04-13", "Personal Work"}
        };

        JTable table = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));

        // Back Button
        JButton backButton = new JButton("Back");
        backButton.setBackground(new Color(46, 204, 113)); // Green
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setPreferredSize(new Dimension(100, 35));
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        backButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                backButton.setBackground(new Color(39, 174, 96));
            }

            public void mouseExited(MouseEvent e) {
                backButton.setBackground(new Color(46, 204, 113));
            }
        });

        backButton.addActionListener(e -> {
            new StudentDashboard().setVisible(true);
            dispose();
        });

        buttonPanel.add(backButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LeaveToTeacher().setVisible(true);
        });
    }
}
