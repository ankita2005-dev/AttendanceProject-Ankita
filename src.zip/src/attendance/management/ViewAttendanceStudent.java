package attendance.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ViewAttendanceStudent extends JFrame {

    public ViewAttendanceStudent() {
        setTitle("Student - View Attendance");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));

        JLabel title = new JLabel("Your Attendance Records", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        // Final updated columns (no remarks)
        String[] columnNames = {"Name", "Roll No", "Class", "Date", "Status"};
        Object[][] data = {
                {"Ishita Sharma", "101", "BCA-1", "2025-04-10", "Present"},
                {"Ishita Sharma", "101", "BCA-1", "2025-04-11", "Absent"},
                {"Ishita Sharma", "101", "BCA-1", "2025-04-12", "Present"}
        };

        JTable table = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Buttons Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));

        // Back Button
        JButton backButton = new JButton("Back");
        backButton.setBackground(new Color(46, 204, 113)); // Green
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setPreferredSize(new Dimension(100, 35));
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        backButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                backButton.setBackground(new Color(39, 174, 96));
            }

            public void mouseExited(MouseEvent e) {
                backButton.setBackground(new Color(46, 204, 113));
            }
        });

        backButton.addActionListener(e -> {
            new StudentDashboard().setVisible(true);
            dispose();
        });

        buttonPanel.add(backButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ViewAttendanceStudent().setVisible(true);
        });
    }
}
