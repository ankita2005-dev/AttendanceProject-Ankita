package attendance.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginPage extends JFrame {

    private JComboBox<String> userTypeDropdown;
    private JTextField usernameInput;
    private JPasswordField passwordInput;
    private JCheckBox showPasswordToggle;

    public LoginPage() {
        setTitle("Login Page");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Open window in center
        setLayout(new BorderLayout());

        // --- Left Panel: Welcome Area ---
        JPanel leftPanel = new JPanel();
        leftPanel.setPreferredSize(new Dimension(300, 600));
        leftPanel.setBackground(new Color(255, 87, 34));
        leftPanel.setLayout(new BorderLayout());

        JLabel welcomeText = new JLabel("<html><center>Welcome to<br>Attendance Management System</center></html>", SwingConstants.CENTER);
        welcomeText.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeText.setForeground(Color.BLACK);
        welcomeText.setBorder(BorderFactory.createEmptyBorder(100, 10, 10, 10));

        leftPanel.add(welcomeText, BorderLayout.CENTER);

        // --- Right Panel: Login Form ---
        JPanel rightPanel = new JPanel();
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setLayout(null); // manual positioning

        JLabel heading = new JLabel("Login Page");
        heading.setFont(new Font("Arial", Font.BOLD, 24));
        heading.setBounds(150, 30, 200, 30);
        rightPanel.add(heading);

        // User Type Selection
        JLabel userTypeLabel = new JLabel("User Type:");
        userTypeLabel.setBounds(100, 90, 100, 25);
        rightPanel.add(userTypeLabel);

        String[] userTypes = {"Teacher", "Student"};
        userTypeDropdown = new JComboBox<>(userTypes);
        userTypeDropdown.setBounds(200, 90, 150, 25);
        userTypeDropdown.setSelectedIndex(-1); // default unselected
        rightPanel.add(userTypeDropdown);

        // Username Input
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(100, 130, 100, 25);
        rightPanel.add(usernameLabel);

        usernameInput = new JTextField();
        usernameInput.setBounds(200, 130, 150, 25);
        rightPanel.add(usernameInput);

        // Password Input
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(100, 170, 100, 25);
        rightPanel.add(passwordLabel);

        passwordInput = new JPasswordField();
        passwordInput.setBounds(200, 170, 150, 25);
        rightPanel.add(passwordInput);

        // Show Password Checkbox
        showPasswordToggle = new JCheckBox("Show Password");
        showPasswordToggle.setBounds(200, 200, 150, 25);
        showPasswordToggle.setBackground(Color.WHITE);
        showPasswordToggle.addActionListener(e -> {
            passwordInput.setEchoChar(showPasswordToggle.isSelected() ? (char) 0 : '•');
        });
        rightPanel.add(showPasswordToggle);

        // Login Button
        JButton loginBtn = new JButton("Login");
        loginBtn.setBounds(100, 250, 100, 30);
        loginBtn.setBackground(new Color(33, 150, 243));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        loginBtn.setFocusPainted(false);

        loginBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                loginBtn.setBackground(new Color(30, 136, 229));
            }
            public void mouseExited(MouseEvent e) {
                loginBtn.setBackground(new Color(33, 150, 243));
            }
        });

        loginBtn.addActionListener(e -> handleLogin());
        rightPanel.add(loginBtn);

        // Clear Button
        JButton clearBtn = new JButton("Clear");
        clearBtn.setBounds(220, 250, 100, 30);
        clearBtn.setBackground(new Color(244, 67, 54));
        clearBtn.setForeground(Color.WHITE);
        clearBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        clearBtn.setFocusPainted(false);

        clearBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                clearBtn.setBackground(new Color(229, 57, 53));
            }
            public void mouseExited(MouseEvent e) {
                clearBtn.setBackground(new Color(244, 67, 54));
            }
        });

        clearBtn.addActionListener(e -> resetFields());
        rightPanel.add(clearBtn);

        // Forgot Password Label
        JLabel forgotPass = new JLabel("<html><u>Forgot Password?</u></html>");
        forgotPass.setBounds(150, 290, 150, 25);
        forgotPass.setForeground(new Color(33, 150, 243));
        forgotPass.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        forgotPass.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                // Future improvement: open forgot password page?
                JOptionPane.showMessageDialog(null, "Please contact admin to reset your password.");
            }
        });

        rightPanel.add(forgotPass);

        // Adding Panels to Frame
        add(leftPanel, BorderLayout.WEST);
        add(rightPanel, BorderLayout.CENTER);
        setVisible(true);
    }

    // Clear input fields
    private void resetFields() {
        userTypeDropdown.setSelectedIndex(-1);
        usernameInput.setText("");
        passwordInput.setText("");
        showPasswordToggle.setSelected(false);
        passwordInput.setEchoChar('•');
    }

    // Dummy login logic — this should connect to database later
    private void handleLogin() {
        String selectedUserType = (String) userTypeDropdown.getSelectedItem();
        String username = usernameInput.getText().trim();
        String password = new String(passwordInput.getPassword());

        if (selectedUserType == null || username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // TODO: Replace this with actual DB check
        if (selectedUserType.equals("Teacher") && username.equals("teacher") && password.equals("pass")) {
            new TeacherDashboard().setVisible(true);
            dispose();
        } else if (selectedUserType.equals("Student") && username.equals("student") && password.equals("pass")) {
            new StudentDashboard().setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        // Launch login UI
        SwingUtilities.invokeLater(LoginPage::new);
    }
}
