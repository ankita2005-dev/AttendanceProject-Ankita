package attendance.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LeaveRequest extends JFrame {

    public LeaveRequest() {
        setTitle("Leave Requests - Teacher Dashboard");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));

        JLabel title = new JLabel("Student Leave Requests", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        // Column headers
        String[] columnNames = {"Name", "Roll No", "Date", "Reason", "Approve"};
        Object[][] data = {
                {"Ishita Sharma", "101", "2025-04-10", "Medical", Boolean.FALSE},
                {"Rohan Malhotra", "102", "2025-04-11", "Personal Work", Boolean.FALSE},
                {"Aditi Mehra", "103", "2025-04-12", "Family Function", Boolean.FALSE}
        };

        JTable table = new JTable(data, columnNames) {
            @Override
            public Class getColumnClass(int column) {
                return column == 4 ? Boolean.class : String.class;
            }
        };

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Buttons Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));

        // Save Button
        JButton saveButton = new JButton("Save");
        saveButton.setBackground(new Color(46, 204, 113)); // Green
        saveButton.setForeground(Color.WHITE);
        saveButton.setFocusPainted(false);
        saveButton.setPreferredSize(new Dimension(100, 35));
        saveButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        saveButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                saveButton.setBackground(new Color(39, 174, 96)); // Darker Green
            }

            public void mouseExited(MouseEvent e) {
                saveButton.setBackground(new Color(46, 204, 113));
            }
        });

        saveButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(null, "Leave approvals saved successfully.");
        });

        // Back Button
        JButton backButton = new JButton("Back");
        backButton.setBackground(new Color(46, 204, 113)); // Green
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setPreferredSize(new Dimension(100, 35));
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        backButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                backButton.setBackground(new Color(39, 174, 96));
            }

            public void mouseExited(MouseEvent e) {
                backButton.setBackground(new Color(46, 204, 113));
            }
        });

        backButton.addActionListener(e -> {
            new TeacherDashboard().setVisible(true);
            dispose();
        });

        buttonPanel.add(saveButton);
        buttonPanel.add(backButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LeaveRequest().setVisible(true);
        });
    }
}
