package attendance.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TeacherDashboard extends JFrame {

    // Constructor to initialize the TeacherDashboard frame
    public TeacherDashboard() {
        // Set the title of the frame and its basic properties
        setTitle("Teacher Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // Close the application when the frame is closed
        setSize(1000, 600);  // Set the window size
        setLocationRelativeTo(null);  // Center the window on the screen
        setLayout(new BorderLayout());  // Use BorderLayout for the main layout of the frame

        // Left panel that will hold the title and navigation buttons
        JPanel leftPanel = new JPanel();
        leftPanel.setBackground(new Color(255, 87, 34)); // Set background color to orange
        leftPanel.setPreferredSize(new Dimension(250, 600));  // Set the size of the left panel
        leftPanel.setLayout(new BorderLayout());  // Use BorderLayout for the left panel

        // Create a label for the title of the dashboard
        JLabel titleLabel = new JLabel("Teacher Dashboard", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));  // Set the font of the title
        titleLabel.setForeground(Color.WHITE);  // Set the text color to white
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 10, 10, 10));  // Add padding around the label
        leftPanel.add(titleLabel, BorderLayout.NORTH);  // Add the title label to the north section of the left panel

        // Panel to hold the navigation buttons
        JPanel navPanel = new JPanel();
        navPanel.setBackground(new Color(255, 87, 34));  // Set background color to match the theme
        navPanel.setLayout(new GridLayout(6, 1, 15, 15));  // Use GridLayout to arrange buttons vertically
        navPanel.setBorder(BorderFactory.createEmptyBorder(20, 10, 10, 10));  // Add padding around the buttons

        // Create the navigation buttons and set their action listeners
        JButton markAttendanceButton = createNavButton("Mark Attendance");
        JButton leaveRequestButton = createNavButton("Leave Requests");
        JButton updateAttendanceButton = createNavButton("Update Attendance");
        JButton viewAttendanceButton = createNavButton("View Attendance");
        JButton logoutButton = createNavButton("Logout");

        // Add the buttons to the navigation panel
        navPanel.add(markAttendanceButton);
        navPanel.add(leaveRequestButton);
        navPanel.add(updateAttendanceButton);
        navPanel.add(viewAttendanceButton);
        navPanel.add(logoutButton);

        // Add the navigation panel to the center section of the left panel
        leftPanel.add(navPanel, BorderLayout.CENTER);

        // Define the actions when a button is clicked
        markAttendanceButton.addActionListener(e -> {
            new MarkAttendance().setVisible(true);  // Open the Mark Attendance page
            dispose();  // Close the current window (TeacherDashboard)
        });

        leaveRequestButton.addActionListener(e -> {
            new LeaveRequest().setVisible(true);  // Open the Leave Requests page
            dispose();
        });

        updateAttendanceButton.addActionListener(e -> {
            new UpdateAttendance().setVisible(true);  // Open the Update Attendance page
            dispose();
        });

        viewAttendanceButton.addActionListener(e -> {
            new ViewAttendance().setVisible(true);  // Open the View Attendance page
            dispose();
        });

        logoutButton.addActionListener(e -> {
            new LoginPage().setVisible(true);  // Open the Login page when the user logs out
            dispose();
        });

        // Right panel to display a welcome message to the teacher
        JPanel rightPanel = new JPanel();
        rightPanel.setBackground(Color.WHITE);  // Set background color to white
        rightPanel.setLayout(new BorderLayout());  // Use BorderLayout for the right panel

        // Create a welcome label for the teacher
        JLabel welcomeLabel = new JLabel("Welcome Teacher", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 28));  // Set font size and style
        welcomeLabel.setForeground(Color.BLACK);  // Set the text color to black
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(50, 10, 10, 10));  // Add padding around the label

        // Add the welcome label to the center section of the right panel
        rightPanel.add(welcomeLabel, BorderLayout.CENTER);

        // Add the left and right panels to the main frame
        add(leftPanel, BorderLayout.WEST);  // Left panel on the west side
        add(rightPanel, BorderLayout.CENTER);  // Right panel in the center of the frame
    }

    // Helper method to create navigation buttons with consistent styling
    private JButton createNavButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);  // Remove focus effect (no border when clicked)
        button.setFont(new Font("Arial", Font.BOLD, 16));  // Set font size and style
        button.setBackground(Color.WHITE);  // Set background color to white
        button.setForeground(new Color(255, 87, 34));  // Set text color to match the theme
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));  // Change cursor to hand when hovered
        button.setPreferredSize(new Dimension(200, 50));  // Set preferred size for the buttons
        return button;  // Return the created button
    }

    // Main method to run the TeacherDashboard application
    public static void main(String[] args) {
        // Ensure that the GUI updates are done on the Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            new TeacherDashboard().setVisible(true);  // Create and display the TeacherDashboard frame
        });
    }
}
