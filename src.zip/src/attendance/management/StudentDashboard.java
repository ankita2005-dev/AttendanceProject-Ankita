package attendance.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class StudentDashboard extends JFrame {

    public StudentDashboard() {
        setTitle("Student Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Left panel (Orange navigation)
        JPanel leftPanel = new JPanel();
        leftPanel.setBackground(new Color(255, 87, 34)); // Orange color
        leftPanel.setPreferredSize(new Dimension(200, 600));
        leftPanel.setLayout(new GridLayout(6, 1, 10, 10));

        JButton viewAttendanceButton = createNavButton("View Attendance");
        JButton leaveToTeacherButton = createNavButton("Leave to Teacher");
        JButton logoutButton = createNavButton("Logout");

        // Add action listeners for navigation
        viewAttendanceButton.addActionListener(e -> {
            new ViewAttendanceStudent().setVisible(true);
            dispose();
        });

        leaveToTeacherButton.addActionListener(e -> {
            new LeaveToTeacher().setVisible(true);
            dispose();
        });

        logoutButton.addActionListener(e -> {
            new LoginPage().setVisible(true);
            dispose();
        });

        leftPanel.add(viewAttendanceButton);
        leftPanel.add(leaveToTeacherButton);
        leftPanel.add(logoutButton);

        // Right panel (White content area)
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BorderLayout());
        rightPanel.setBackground(Color.WHITE);

        JLabel welcomeLabel = new JLabel("Welcome Student", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 26));
        welcomeLabel.setForeground(Color.BLACK);
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(20, 10, 10, 10));

        rightPanel.add(welcomeLabel, BorderLayout.NORTH);

        // Add panels to the main frame
        add(leftPanel, BorderLayout.WEST);
        add(rightPanel, BorderLayout.CENTER);
    }

    private JButton createNavButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(Color.WHITE);
        button.setForeground(new Color(255, 87, 34));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return button;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new StudentDashboard().setVisible(true);
        });
    }
}
