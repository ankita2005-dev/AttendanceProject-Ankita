package attendance.management;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class ViewAttendance extends JFrame {

    private DefaultTableModel tableModel;

    public ViewAttendance() {
        setTitle("View Attendance");
        setSize(900, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel heading = new JLabel("Attendance Records", SwingConstants.CENTER);
        heading.setFont(new Font("Arial", Font.BOLD, 22));
        heading.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(heading, BorderLayout.NORTH);

        // Column names
        String[] columns = {"Student Name", "Roll No", "Class", "Status", "Remarks"};

        // Dummy attendance data
        Object[][] data = {
            {"Rohan Malhotra", "101", "BCA1", "Present", ""},
            {"Ishita Sharma", "102", "BCA1", "Absent", ""},
            {"Aman Gupta", "105", "BCA1", "Present", ""}
        };

        tableModel = new DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4; // Only Remarks column editable
            }
        };

        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Bottom panel
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton saveButton = new JButton("Save");
        JButton backButton = new JButton("Back");

        // Save button functionality
        saveButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Remarks saved successfully!");
            new TeacherDashboard().setVisible(true);
            dispose();
        });

        // Back button functionality
        backButton.addActionListener(e -> {
            new TeacherDashboard().setVisible(true);
            dispose();
        });

        // Styling
        saveButton.setBackground(new Color(33, 150, 243)); // Blue
        saveButton.setForeground(Color.WHITE);
        saveButton.setFocusPainted(false);

        backButton.setBackground(Color.GRAY);
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);

        bottomPanel.add(backButton);
        bottomPanel.add(saveButton);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ViewAttendance().setVisible(true));
    }
}
