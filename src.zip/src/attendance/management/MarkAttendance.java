package attendance.management;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class MarkAttendance extends JFrame {
    private JTable table;

    public MarkAttendance() {
        setTitle("Mark Attendance");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Heading
        JLabel heading = new JLabel("Mark Attendance", SwingConstants.CENTER);
        heading.setFont(new Font("Arial", Font.BOLD, 22));
        heading.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        add(heading, BorderLayout.NORTH);

        // Table data
        String[] columnNames = {"Name", "Class", "Roll No", "Status", "Remarks"};
        Object[][] data = {
            {"Rohan Malhotra", "BCA1", "101", "Present", ""},
            {"Ishita Sharma", "BCA1", "102", "Absent", ""},
            {"Aman Verma", "BCA1", "103", "Present", ""},
            {"Neha Singh", "BCA1", "104", "Present", ""},
            {"Arjun Mehra", "BCA1", "105", "Absent", ""}
        };

        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column >= 3; // Allow editing of Status and Remarks
            }
        };

        table = new JTable(model);

        // Set dropdown for Status column
        JComboBox<String> statusCombo = new JComboBox<>(new String[]{"Present", "Absent"});
        table.getColumnModel().getColumn(3).setCellEditor(new DefaultCellEditor(statusCombo));

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Save and Back Panel
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.RIGHT, 15, 15));

        JButton saveButton = new JButton("Save");
        saveButton.setBackground(new Color(33, 150, 243)); // Blue
        saveButton.setForeground(Color.WHITE);
        saveButton.setFocusPainted(false);
        saveButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JButton backButton = new JButton("Back");
        backButton.setBackground(new Color(76, 175, 80)); // Green
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // Hover effects
        saveButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                saveButton.setBackground(new Color(30, 136, 229));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                saveButton.setBackground(new Color(33, 150, 243));
            }
        });

        backButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                backButton.setBackground(new Color(56, 142, 60));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                backButton.setBackground(new Color(76, 175, 80));
            }
        });

        // Button Actions
        saveButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Attendance saved successfully!");
        });

        backButton.addActionListener(e -> {
            new TeacherDashboard().setVisible(true);
            dispose();
        });

        bottomPanel.add(backButton);
        bottomPanel.add(saveButton);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MarkAttendance().setVisible(true));
    }
}
